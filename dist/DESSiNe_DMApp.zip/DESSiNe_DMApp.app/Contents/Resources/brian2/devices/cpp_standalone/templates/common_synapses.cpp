{% extends 'common_group.cpp' %}
{% block extra_headers %}
#include "brianlib/stdint_compat.h"
#include "synapses_classes.h"
{% endblock %}
